# Документация проекта 


## Галерея исскуств


### Шрифты

<ul>
    <li>'Unbounded'</li>
</ul>


### Цветовая коррекция
<ul>
     <li> white</li>
     <li>black</li>
</ul>

### Фреймворк и технологии
<ul>
    <li>HTML5</li>
    <li>CSS3</li>
</ul>